# in lab1 pdf:
    - 19,10,11,28
    - main -> application -> llopen -> control packet -> envia pacotes de file -> llwrite/llread -> control packet end -> llclose
    - byte stuffing/destuffing no caso de flag